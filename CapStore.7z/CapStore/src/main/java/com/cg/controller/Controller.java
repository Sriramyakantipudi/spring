package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Cap;
import com.cg.exception.CapException;
import com.cg.service.CapService;

//@CrossOrigin(origins="http://localhost:4200")
@RestController
public class Controller 
{
@Autowired
CapService Service;

@RequestMapping(value="/add", method=RequestMethod.POST)
public void addproduct(@RequestBody Cap b) throws CapException{
	Service.addProduct(b);
}

@RequestMapping(value="/set/{id}")
public void setStatus(@PathVariable int product_id) throws CapException
{
	Service.setStatus(product_id);	 
}

@RequestMapping(value="/get/{id}" ,method=RequestMethod.GET)
public String getStatus(@PathVariable int product_id) throws CapException
{
	return Service.getStatus(product_id);	 
}
}

package com.cg.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class ExceptionController
{
	public ResponseEntity<String> handleException(Exception ex)
	{
		return new ResponseEntity<String> ("Error: "+ex.getMessage(),HttpStatus.CONFLICT);
	}
}


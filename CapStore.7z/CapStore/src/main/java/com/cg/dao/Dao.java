package com.cg.dao;

import java.sql.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.bean.Cap;

@Repository
public interface Dao extends JpaRepository<Cap,Integer>
{
	
	@Query("select d from Cap")
	Date getDateOfOrdering();

	@Query("select noOfDaysForDelivery from Cap")
	int getNoOfDays();


	
	
}

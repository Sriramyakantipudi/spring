package com.cg.service;

import com.cg.bean.Cap;
import com.cg.exception.CapException;

public interface CapService 
{	
	public void addProduct(Cap b);
	public void setStatus(int product_id)throws CapException;
	public String getStatus(int product_id)throws CapException;	
}

package com.cg.service;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.bean.Cap;
import com.cg.dao.Dao;
import com.cg.exception.CapException;

@Service
public class CapServiceImpl implements CapService
{
@Autowired
Dao dao;
String dOfOrderd;
String e;

@Override
public void addProduct(Cap b) {
	dao.save(b);	
}
@Override
public void setStatus(int id) throws CapException {
	
	Optional<Cap> c=dao.findById(id);
	if(c.isPresent())
	{
		Cap c1=c.get();
		dOfOrderd=c1.getdateOfOrd();
		int noOfdays=c1.getnoOfDaysForDelivery();
		Date currentDate = Calendar.getInstance().getTime();
		DateFormat dateFormat = new SimpleDateFormat("dd-mm-yyyy");  
		String strDate = dateFormat.format(currentDate);
		int diffDays=(Integer.parseInt(dOfOrderd.substring(0, 2)))-(Integer.parseInt(strDate.substring(0, 2)));
	    // long diff =  dOfOrderd.getTime() - currentDate.getTime();
	     //long diffDays = diff / (24 * 60 * 60 * 1000);
	     
	     if(diffDays==0)
	     {
	      e="order placed";
	     }
	     if(diffDays <noOfdays)
	     {
	      if(diffDays==1 || diffDays==2)
	      {
	    	 e="order dispatched";
	     }
	     else if(diffDays==3 || diffDays==4 || diffDays==5)
	     {
	    	 e="order shipped";
	     }
	     else if(diffDays==6)
	     {
	    	 e="out for delivery";
	     }
	    
	     }
	     else 
	     {
	    	 e="order delivered";
	     }
	     c1.setStatus(e);
	     dao.save(c1);
	}
     //dOfOrderd=dao.getDateOfOrdering();
     //int noOfdays=dao.getNoOfDays();
     
     	
}

@Override
public String getStatus(int id) throws CapException {
	Optional<Cap> c=dao.findById(id);
	Cap c1=null;
	if(c.isPresent())
	{
		c1=c.get();
	}
	return c1.getStatus();
}

}




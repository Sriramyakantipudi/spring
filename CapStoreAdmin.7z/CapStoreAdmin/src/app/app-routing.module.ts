import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { GetCustomerComponent } from './get-customer/get-customer.component';
import { GetMerchantComponent } from './get-merchant/get-merchant.component';
import { ManageMerchantComponent } from './manage-merchant/manage-merchant.component';
import { CouponsComponent } from './coupons/coupons.component';
const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'get-customer', component: GetCustomerComponent },
  { path: 'get-merchant', component: GetMerchantComponent },
  { path: 'manage-merchant', component: ManageMerchantComponent },
  { path: 'coupons', component: CouponsComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

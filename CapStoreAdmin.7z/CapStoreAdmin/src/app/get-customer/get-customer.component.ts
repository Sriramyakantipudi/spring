import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-customer',
  templateUrl: './get-customer.component.html',
  styleUrls: ['./get-customer.component.css']
})
export class GetCustomerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

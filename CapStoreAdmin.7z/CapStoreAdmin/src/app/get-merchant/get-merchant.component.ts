import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-merchant',
  templateUrl: './get-merchant.component.html',
  styleUrls: ['./get-merchant.component.css']
})
export class GetMerchantComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

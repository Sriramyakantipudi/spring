package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.entities.Employee;
import com.cg.service.EmpService;

@Controller
public class EmployeeController { 
	@Autowired
	EmpService employeeService;
	@RequestMapping("/index")
	public String getHomePage(Model model) {
		model.addAttribute("designations",new String[] {"System Associate","asst manager","manager"});
		model.addAttribute("employee", new Employee());
		return "index";
	}
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String saceEmployee(@ModelAttribute("employee")Employee employee,Model model) {
		
		Employee empRes=employeeService.save(employee);
		return "redirect:/index.html";		
	}
 
}

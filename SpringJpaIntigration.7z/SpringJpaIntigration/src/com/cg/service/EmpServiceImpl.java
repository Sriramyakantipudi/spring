package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.EmpDao;
import com.cg.entities.Employee;

@Service
@Transactional
public class EmpServiceImpl implements EmpService {
	@Autowired
	EmpDao employeeDao;

	@Override
	public Employee save(Employee employee) {
		// TODO Auto-generated method stub
		employeeDao.save(employee);
		return null;
	}

	@Override
	public List<Employee> loadAll() {
		// TODO Auto-generated method stub
		employeeDao.loadAll();
		return null;
	}
	

}
